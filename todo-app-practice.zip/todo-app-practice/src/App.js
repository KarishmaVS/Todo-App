import React from "react";
import "./App.css";
import Todo from "../src/components/screens/Todo";

class App extends React.Component {
	render() {
		return <Todo />;
	}
}

export default App;
